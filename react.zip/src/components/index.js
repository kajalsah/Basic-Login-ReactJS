export { default as Navigation } from "./Navigation";
export { default as Footer } from "./Footer";
export { default as Home } from "./Home";
export { default as About } from "./About";
export { default as Dashboard } from "./Dashboard";
export { default as Register } from "./Register";
